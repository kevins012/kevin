<?php 
require "../function.php";
require "../bootstrap/header.php";
require "../formedit.php";
session_start();
if(!isset($_SESSION['login'])){
	header("location: http://localhost/phpdasar/myprojek/login.php");
	exit;
}
$id = $_GET['id'];
if (isset($_POST["kirim"]) ) {
    $new_title = $_POST["title"];
    $new_content = $_POST["content"];
    
    $kondisi = query("UPDATE category SET title = '$new_title',content = '$new_content',created_at = CURRENT_TIMESTAMP() WHERE ID='$id'",1);
    
    if($kondisi === true){
        header("location: category.php?nomor=0");
    }
}
if(isset($_POST["cancel"])){
    header("location: category.php?nomor=0");
}
$old_data = query("SELECT *FROM category WHERE ID = '$id'",0);

$data =query("SELECT * FROM page LEFT JOIN category ON (page.id_category = category.ID) WHERE page.ID = '$id'",0);
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=HELOO, initial-scale=1.0">
    <?php
     links();
    ?>
</head>
<body>
<?php
 formedit(3,$data); ?>
</body>
</html>