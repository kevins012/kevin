<?php 
require "../formedit.php";
require "../function.php";
require "../bootstrap/header.php";
session_start();
if(!isset($_SESSION['login'])){
	header("location: http://localhost/phpdasar/myprojek/login.php");
	exit;
}
if (isset($_POST["kirim"]))
{
    $new_title = $_POST["title"];
    $new_content = $_POST["content"];
    
    $kondisi = query("INSERT INTO category (ID,  title, content, status, created_at) VALUES ('', '$new_title', '$new_content', '1', CURRENT_TIMESTAMP())",1);
    
    if($kondisi === true){
        header("location: category.php?nomor=0");
    }
}if(isset($_POST["cancel"])){
    header("location: category.php?nomor=0");
}


 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
     links();
    ?>
    <title>Document</title>
</head>
<body>
    <?php formedit(3,0);?>
    
</body>
</html>