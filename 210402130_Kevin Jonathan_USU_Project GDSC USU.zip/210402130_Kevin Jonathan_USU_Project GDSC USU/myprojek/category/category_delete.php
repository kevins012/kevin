<?php
require "../function.php";
if (isset($_GET['id'])){
    $id = $_GET['id'];
    query("UPDATE  page JOIN category ON (page.id_category = category.ID) SET page.status = '0' WHERE page.id_category = '$id'  AND category.status = '1'",1);
    query("UPDATE category SET status = '0',created_at = CURRENT_TIMESTAMP() WHERE ID='$id'",1);
    
    header("location: category.php?nomor=0");

}
?>