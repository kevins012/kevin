
<?php
session_start();
if(!isset($_SESSION['login'])){
	header("location: http://localhost/phpdasar/myprojek/login.php");
	exit;
}
require "bootstrap/header.php";

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Hello, world!</title>
  </head>
  <body>
    <!-- Navbar -->
    <?php
       headers();
    ?>
<section class="jumbotron text-center" >

<button class="button1"><img src="img/usu2.png"></button>
      
  <h1 class="display-4">   Kevin Jonathan</h1>
  <p class ="lead">USU | 2023/2024</p>
  <p class="lead">
Fakultas Teknik  ||  Teknik Elektro</p>

  
  <a class="btn btn-primary btn-lg" href="#" role="button">My Account</a>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#fff" fill-opacity="10" d="M0,64L16,58.7C32,53,64,43,96,69.3C128,96,160,160,192,197.3C224,235,256,245,288,240C320,235,352,213,384,197.3C416,181,448,171,480,181.3C512,192,544,224,576,213.3C608,203,640,149,672,106.7C704,64,736,32,768,42.7C800,53,832,107,864,149.3C896,192,928,224,960,240C992,256,1024,256,1056,250.7C1088,245,1120,235,1152,197.3C1184,160,1216,96,1248,101.3C1280,107,1312,181,1344,176C1376,171,1408,85,1424,42.7L1440,0L1440,320L1424,320C1408,320,1376,320,1344,320C1312,320,1280,320,1248,320C1216,320,1184,320,1152,320C1120,320,1088,320,1056,320C1024,320,992,320,960,320C928,320,896,320,864,320C832,320,800,320,768,320C736,320,704,320,672,320C640,320,608,320,576,320C544,320,512,320,480,320C448,320,416,320,384,320C352,320,320,320,288,320C256,320,224,320,192,320C160,320,128,320,96,320C64,320,32,320,16,320L0,320Z"></path></svg>
</section>
<section class="about " >
    <div class="container">
 

    <div class="row text-center mb-3">
    
    <div class="col"><h1>About Me</h1></div>
    
  </div>
<div class="row justify-content-center fs-5 text-center" >
    
    <div class="col-4">
      <p>Halo nama saya bajang , hey yo whatsapp yag m , dmana mana hatiku senang, dirumah senang, digereja senang, sesuatu yang harus kulakukan adalah hal hal yang memanjakan mata</p>
    </div>
    <div class="col-4">
    <p>Halo nama saya bajang , hey yo whatsapp yag m , dmana mana hatiku senang, dirumah senang, digereja senang, sesuatu yang harus kulakukan adalah hal hal yang memanjakan mata</p>
    </div>
    
  </div>
  </div>
  <a href="admin.php">KONTENKU</a>
 

  

</section>

    <!-- Header -->

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="scrip1.js"></script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>