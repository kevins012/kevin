<?php
$conn = mysqli_connect("localhost","root","","myproject","8111");



function query($query,$i) {
    global $conn;
    
    $kontenku = mysqli_query($conn,$query);

    if ($i==0) {
        $rows = [];
        while ($row = mysqli_fetch_assoc($kontenku)){
       
             array_push($rows, $row);
            
        }
    
        return $rows;
    }
        else {
            return $kontenku ;       }
}

function edit($kontenku,$data) {
}
function regis($data){
    global $conn;
    $pw = mysqli_escape_string($conn,$data["password"]);
    $pw2 = mysqli_escape_string($conn,$data["password2"]);
    $usr = strtolower(stripslashes($data["username"]));

    $email = $data["email"];
    $noHp = $data["NoHP"];

    $result=mysqli_query($conn,"SELECT username,email,noHp FROM user WHERE username = '$usr' OR email='$email' OR noHp ='$noHp'");
	
	if(mysqli_fetch_assoc($result)){
        echo "<script>
		alert('Data Sudah ada');</script>";
		

		

		return false;
    }
    if ($pw!==$pw2){
        echo "<script>
		alert('Password tidak sama dengan konfirmasi password');</script>";
        return false;

    }
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        print("salah format email");
        return false;

    }
    $pw = password_hash($pw, PASSWORD_DEFAULT);
    mysqli_query($conn, "INSERT INTO user VALUES('', '$usr', '$pw', '$email', '$noHp', current_timestamp())");


	return mysqli_affected_rows($conn);




}
?>