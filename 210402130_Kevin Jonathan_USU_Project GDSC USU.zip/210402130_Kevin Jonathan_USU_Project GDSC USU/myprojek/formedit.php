<?php
function formedit($ax,$datas){
    global $old_data;
    $datacategory = query("SELECT  * FROM category WHERE status = '1'",0);
    headers();
    ?>
    
    <form action="" method="post">
        <div class="m-5">

            <div class="form-floating mb-3">
            <textarea class="form-control" placeholder="Title" id="floatingTextarea" name="title"><?php 
            if(isset($_GET['id'])){echo $old_data[0]["title"];
                    }else {
                        echo "";
                        } ?></textarea>
            <label for="title">Title</label>
            </div>
            <?php if ($ax==1){
                
                ?>
            
            <select class="form-select" aria-label="Default select example" name="category">
                <option selected value="<?=$datas[0]["id_category"]?>"><?=$datas[0]["title"]?></option>
                <?php foreach($datacategory as $mydata=>$val){ ?>
                <option value="<?=$val["ID"]?>" ><?=($val["title"]);?></option>
                <?php }?>
            </select>
            <?php }
            else if($ax==0){ ?>
                <select class="form-select" aria-label="Default select example" name="category">
                <option selected value=""></option>
                <?php foreach($datacategory as $mydata=>$val){ ?>
                <option value="<?=$val["ID"]?>" ><?=($val["title"]);?></option>
                <?php }?>
            </select><?php
                


                
                }?>
          
        <div class="form-floating mb-3">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"  name="content"><?php if(isset($_GET['id'])){echo $old_data[0]["content"];}else {echo"";} ?></textarea>
            <label for="content">Content</label>
        </div>
            <div class="form-floating mb-3 button0" >


            <button type="submit" class="btn btn-outline-primary m-8" name="kirim">Submit</button>
            <button type="submit" class="btn btn-outline-primary" name="cancel">Batal</button>
            </div>
        </div>
    </form>
<?php
}?>