<?php 
require "../formedit.php";
require "../function.php";
require "../bootstrap/header.php";
session_start();
if(!isset($_SESSION['login'])){
	header("location: http://localhost/phpdasar/myprojek/login.php");
	exit;
}
if (isset($_POST["kirim"]))
{
    $new_title = $_POST["title"];
    $new_content = $_POST["content"];
    $id_category = $_POST["category"];
    
    $kondisi = query("INSERT INTO page (ID,id_category,  title, content, status, created_at) VALUES ('','$id_category' ,'$new_title', '$new_content', '1', CURRENT_TIMESTAMP())",1);
    
    if($kondisi === true){
        header("location: page.php?nomor=0");
    }
}if(isset($_POST["cancel"])){
    header("location: page.php?nomor=0");
}


 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
     links();
    ?>
    <title>Document</title>
</head>
<body>
    <?php formedit(0,0);?>
    
</body>
</html>