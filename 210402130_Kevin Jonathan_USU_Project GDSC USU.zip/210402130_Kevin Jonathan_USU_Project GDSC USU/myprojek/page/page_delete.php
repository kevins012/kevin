<?php
require "../function.php";
if (isset($_GET['id'])){
    $id = $_GET['id'];
    query("UPDATE page SET status = '0',created_at = CURRENT_TIMESTAMP() WHERE ID='$id'",1);
    header("location: page.php?nomor=0");

}
?>