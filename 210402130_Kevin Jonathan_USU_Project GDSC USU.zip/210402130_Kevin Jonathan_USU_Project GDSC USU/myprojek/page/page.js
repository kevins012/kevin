const categ = document.querySelectorAll('.pilihanCat');
const categ1 = document.querySelectorAll('.categoryku');
const readmore = document.querySelectorAll('.readmore');
const completeText = document.querySelectorAll('.completeText');

completeText.forEach(function (co) {
  co.display = 'none';
});

readmore.forEach(function (read) {
  read.addEventListener('click', function (re) {
    console.log('Button clicked!');

    // Get the computed style of the element
    var computedStyle = window.getComputedStyle(re.target.previousElementSibling);

    // Check the current display value
    var currentDisplay = computedStyle.getPropertyValue('display');

    // Toggle the display value
    if (currentDisplay === 'none') {
      re.target.previousElementSibling.style.display = 'inline-block';
      read.innerHTML = 'back';
    } else if (currentDisplay === 'inline-block') {
      re.target.previousElementSibling.style.display = 'none';
      read.innerHTML = 'read more';
    }

    // Log the updated display value
    console.log(re.target.previousElementSibling.style.display);
  });
});
