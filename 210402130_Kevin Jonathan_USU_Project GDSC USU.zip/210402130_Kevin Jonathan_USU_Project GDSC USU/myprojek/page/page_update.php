<?php 
require "../function.php";
require "../bootstrap/header.php";
require "../formedit.php";
session_start();
if(!isset($_SESSION['login'])){
	header("location: http://localhost/phpdasar/myprojek/login.php");
	exit;
}
$id = $_GET['id'];

if (isset($_POST["kirim"]) ) {
    echo $_POST["category"];
 
   
    $new_title = $_POST["title"];
    $new_content = $_POST["content"];
    $categ = $_POST["category"];
    try {
        $kondisi = query("UPDATE page SET title = '$new_title',id_category='$categ',content = '$new_content',created_at = CURRENT_TIMESTAMP() WHERE ID='$id'",1);
        if($kondisi == 1){
            header("location: page.php?nomor=0&id_category=$categ");
        
    }
        //code...
    } catch (\Throwable $th) {
        header("location: page.php?nomor=0");
        //throw $th;
    }
    
   
    
   
    
}
if(isset($_POST["cancel"])){
    header("location: page.php?nomor=0");
}
$old_data = query("SELECT *FROM page WHERE ID = '$id'",0);
$data3 =query("SELECT * FROM page LEFT JOIN category ON (page.id_category = category.ID) WHERE page.ID = '$id'  AND category.status = '1'",0);
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=HELOO, initial-scale=1.0">
    <?php
     links();
    ?>
</head>
<body>
<?php
 formedit(1,$data3); ?>

</body>
</html>