<?php

use function PHPSTORM_META\type;

require "../function.php";
require "../bootstrap/header.php";
session_start();
if(!isset($_SESSION['login'])){
	header("location: http://localhost/phpdasar/myprojek/login.php");
	exit;
}
$data2 = query("SELECT  * FROM page WHERE status = '1'",0);






  





$dataperpage = 3;

$dataawal = $_GET["nomor"]*$dataperpage ;

$data5 =query("SELECT * FROM page JOIN category ON (page.id_category = category.ID) LIMIT $dataawal,$dataperpage  ",0);
$data3 =query("SELECT * FROM page LEFT JOIN category ON (page.id_category = category.ID) LIMIT $dataawal,$dataperpage",0);


$data1 = query("SELECT  * FROM page WHERE status = '1' LIMIT $dataawal,$dataperpage",0);




$allpage = count($data1);

$nomorPagination = ceil(count( $data2 ) / $dataperpage );


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
     links();
    ?>

   

    <title>Document</title>
</head>

<body> 

<?php headers();  $aa = 0;?>
<div class="accordion" id="accordionPanelsStayOpenExample">
    
<?php for ($i=0; $i <$allpage; $i++) { 
  
    $target = "panelsStayOpen-collapse".$i;
        # code...
    ?>
  <div class="accordion-item">
  
    <h2 class="accordion-header">
   
      <div class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#<?=$target?>" aria-expanded="true" aria-controls="<?=$target?>">
      <?php 
      
      echo $data1[$i]["title"] ;

      
           
      ?>
    </div>
    </h2>
    
    <div id="<?=$target?>" class="accordion-collapse collapse show">
      <div class="accordion-body"><span><?php echo substr($data1[$i]["content"],0,20);?></span><span class="completeText"><?=substr($data1[$i]["content"],20,strlen($data1[$i]["content"])); ?></span>
      <?php if (strlen($data1[$i]["content"])>= 20){
        ?><span class="readmore">read more</span><?php }?>

  
        
      
     
      </div>
      <div class="edit1">
        <a href="page_update.php?id=<?=$data1[$i]["ID"];?>" class="edit">Edit</a>
        <a href="page_delete.php?id=<?=$data1[$i]["ID"];?>" class="delete">Delete</a>
      </div>
      <div>
        Category :<?php 
       
          echo $data3[$i]["title"];
       
        
        
        
       ?>
      </div>
      
    </div>
  </div>
  <?php } ?><a href="page_add.php" class="add">Add</a>
  
</div>
<nav aria-label="Page navigation example">
  <ul class="pagination">
  <?php if($_GET["nomor"] != 0) { ?>
    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
  <?php } 

  for ($i = 1; $i <= $nomorPagination; $i++) { ?>
      <li class="page-item"><a class="page-link" href="?nomor=<?= $i-1; ?>"><?= $i; ?></a></li>
  <?php }

  if($_GET["nomor"] != $nomorPagination-1) { ?>
      <li class="page-item"><a class="page-link" href="#">Next</a></li>
  <?php } ?>
  

  </ul>
</nav>




<script src = "page.js"></script>
</body>
</html>







<!---

yang akan ditanyakan untuk hari sabtu nanti

mengapa kadang kadang Mysql XAMPP tidak berjalan
apa itu $_SERVER dan $_REQUEST
saya pernah coba program, check box yang berclass pilihan, jadi saya buat 
if (isset($_POST["pilihan"])) {
  echo "<script>alert('data berhasil dihapus!')</script>; ";
}
maka saat saya tekan checkboxnya maka tidak dieksekusi script diatas, tetapi jika saya tambah post button tag, lalulah tereksekusi condition diatas mengapa itu bsa terjadi
tetapi tunggu direfresh dulu halaman webnya

apakah pada js bisa query

bagaimana mengirim variable yang ada di php ke javascript

mengapa saat kita panggil links() tetapi link style css di dalam fungsi tersebut tidak dieksekusi




 -->

