
<?php 
require "function.php";
session_start();

//cek cookie
if(isset($_COOKIE['id']) && isset($_COOKIE['key'])){
	$id=$_COOKIE['id'];
	$key=$_COOKIE['key'];
	$result=mysqli_query($conn,"SELECT Username FROM user WHERE id=$id");
	$row = mysqli_fetch_assoc($result);

	if($key===hash('sha256',$row['Username'])){
		$_SESSION['login']=true;
	}

}

if(isset($_SESSION['login'])){
	header("location: index.php");
	exit;
}

if(isset($_POST["login"]) ){

	$pw = $_POST["password"];
	$usr = $_POST["username"];
	
	$result=mysqli_query($conn,"SELECT * FROM user WHERE username ='$usr'");

	if(mysqli_num_rows($result)===1){

		//cek password
		//cek password
		$row = mysqli_fetch_assoc($result);
		if(password_verify($pw, $row["password"])){
			$_SESSION['login'] = true;
			//cek rememberme
			if(isset($_POST["remember"])){
				setcookie('id',$row['ID'],time()+60);
				setcookie('key',hash('sha256', $row['Username']),time()+60);


			}
			header("location: index.php");
			exit;
		}
		


	}
/////////////////////////////////////////////////////////

$error =true;

	} 
	
	


	
	

	



	


?>


<!DOCTYPE html>
<html lang="en">
<head>
   
   
   <link rel="stylesheet" href="styleLogin.css">
    <title style="color:yellow;">LOGIN</title>



</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2 >LOGIN</h2>
			<?php 
	if(isset($error)) {
	 ?><p style="color: white; font-style:italic;">username/password salah</p> 
	<?php 
		} ?>

            <div class="inputan">
           <form action="" method="post" >
			<label for="username"></label><br>
	
			
			<input type="text" id="username" class="inputLogin" name="username"  autofocus  placeholder="Username" autocomplete="off">
			
	

		


		<br>

		<label for="password"> </label><br>
		<input type="password" id="password" class="inputLogin" name="password" autofocus  placeholder='Password' autocomplete="off">
		<br><br>
		<button type="submit" id="submit" name="login">Login</button>
		<br><br>
		

		<a href="regis.php" style="color:red ; text-decoration: none;">Sign Up</a>
		<br>
		<input type="checkbox" name="remember" id="remember">
		<label for="remember" style="color: white;">Remember Me</label>
</div>
			

	
		




	</form>
        </div>
    </div>
</body>
</html>