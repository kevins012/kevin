
<?php 
require "function.php";

	if(isset($_POST["regis"]) ){
		if (regis($_POST)>0){
			echo "<script>
		alert('new user has been added');</script>";


		}



		


} 
		
		

		
	
	

	











 ?>




















	<!DOCTYPE html>
<html lang="en">
<head>
   
   
   <link rel="stylesheet" href="styleRegis.css">
    <title style="color:yellow;">LOGIN</title>



</head>
<body>
    <div class="login-container">
      
            <h2 >SIGN UP</h2>

           
           <form action="" method="post" id="regis-form">
			<label for="username"></label><br>
	
			
			<input type="text" id="username" class="inputLogin" name="username"  autofocus  placeholder="Username"pattern="^(?!\s)(?!.*\s$)[A-Za-z0-9]{7,20}$"title="Username tidak sesuai kriteria ." required>
			<br>
	

		<label for="Email"></label><br>
	
			
			<input type="email" id="Email" class="inputLogin" name="email"  autofocus  placeholder="Email">
			

<br>
		<label for="NoHP"></label><br>
	
			
			<input type="text" id="NoHP" class="inputLogin" name="NoHP"  autofocus  placeholder="No.HP" min="1" max="10000000" pattern='[0-9]{6,15}' title = 'Must number 'required>
			<br>

		<label for="password"> </label><br>
		<input type="password" id="password" class="inputLogin" name="password" autofocus  placeholder='Password'  required >
		<!-- pattern="^(?!\s)(?!.*\s$)[A-Za-z0-9]{7,20}$"title="Password tidak sesuai kriteria ." -->
		<br>
		<label for="password2"> </label><br>
		<input type="password" id="password2" class="inputLogin" name="password2" autofocus  placeholder='Konfirmasi Password'>
		<br>
		<p id="error-message" style="color: white;"></p>
		<a href="login.php" style="color:burlywood;font-size: 15px ; text-decoration: none; ">Sign In</a>
		<br><br>
		<button type="submit" id="submit" name="regis" onclick="validatePasswords()">Register</button>
		
	
		

			

	
		




	</form>
        
    </div>
    <script src="js_test/js_regis.js"></script>
</body>
</html>
