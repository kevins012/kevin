

<?php
global $index;
$index = "http://localhost/phpdasar/myprojek";

function links(){ 
  global $index;?>

    <link href="<?=$index?>/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?php
}

function headers(){
  global $index;

  
  $page="$index/page/page.php?nomor=0";
  $category = "$index/category/category.php?nomor=0";
  ?>


    
<nav class="navbar navbar-expand-lg navbar-dark bg-danger bg-gradient shadow-lg " >
  <div class="container">
    <a class="navbar-brand" href="#">WaiT</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto padding1">
        <li class="nav-item">
          <a class="nav-link active"  href="<?=$index ?>">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?=$page?>">Page</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?=$category?>">Category</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Account</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" name ="logout" href="http://localhost/phpdasar/myprojek/logout.php">Log Out</a>
        </li>
        
      </ul>
    </div>
  </div>

  
</nav>


<?php
}
?>