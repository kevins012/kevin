Project Web development 
Nama : Kevin Jonathan Sinaga
NIM :210402130
Email :kevin_jonathan_sinaga01@students.usu.ac.id


Ini project web development menggunakan php dengan Web server Apache

Cara menjalankannya 
1. Install xampp lalu  buka xampp dan start action dari Apache dan MySQL
2. lalu salin folder myproject atau semua file di dalam folder my project, nnti buat path jika di windows  
   C:\xampp\htdocs\phpdasar\myprojek jadi seperti ini, my project di path ini adalah foleder myproject tadi, ini dikarenakan menyesuaikan program require atau src atau href dari program php yang saya buat, agar menyesuaikan  folder yang ada
3. buka localhost/phpmyadmin di web browser anda lalu buat data base baru dengan nama db = 'myproject' lalu setelah dibuat, masuk ke dlm database lalu klik import lalu masukkan file myproject.sql ini
5. download bootstrap@5.3.2 
4. jalankan program dengan http://localhost/phpdasar/myprojek/login.php di url web browser anda


Maaf jika ada kesalahan , dan inilah project saya , project CRUD php tanpa framework php kecuali memakai untuk framework html-css dengan memakai bootstrap, tetapi project ini fberfokuskan mengasah dasar untuk backend kedepannya
maaf jika program pada akhirnya ada error ataupun tidak sesuai ekspetasi dan maaf juga jika susunan programnya tidak rapi 
TERIMAKASIH ATAS PERHATIANNYA, ABG KAKAK , BAPAK IBU ATAU SIAPAPUN YANG MELIHAT PROJECT INI, TERIMAKASIH