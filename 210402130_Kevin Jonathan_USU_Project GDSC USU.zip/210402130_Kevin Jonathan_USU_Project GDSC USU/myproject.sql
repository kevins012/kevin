-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8111
-- Waktu pembuatan: 16 Mar 2024 pada 06.07
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `category`
--

CREATE TABLE `category` (
  `ID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `category`
--

INSERT INTO `category` (`ID`, `title`, `content`, `status`, `created_at`) VALUES
(2, 'edfaaa', 'sssssssaaass', 0, '2024-03-16 04:48:10'),
(4, 'hbg', 'rereet', 1, '2024-03-16 04:39:48'),
(6, 'hyhu', 'hyhyhyh', 1, '2024-03-16 04:44:19'),
(7, 'fddfvf', 'vffvvvdfv', 1, '2023-12-01 13:48:46'),
(8, 'Hobbit', 'Enak filmnya', 1, '2024-03-16 04:49:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `page`
--

CREATE TABLE `page` (
  `ID` int(255) NOT NULL,
  `id_category` int(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `page`
--

INSERT INTO `page` (`ID`, `id_category`, `title`, `content`, `status`, `created_at`) VALUES
(2, 2, 'Historygv', 'aHistory of Lorem iffpum dolor sit amet, consectetur adipiscing elit. Nulla aliquam facilisis mi in finibus. Nam ac elit cursus, dictum leo quis, vehicula felis. Vestibulum arcu ligula, interdum at iaculis sit amet, rutrum vitae sapien. Maecenas molestie nisi bibendum, laoreet quam quis, fringilla urna. Mauris dignissim mi quis tortor suscipit faucibus. In tortor leo, tempus semper nisi mattis, finibus egestas massa. Morbi eu ultrices sapien. Ut id nulla luctus, sodales nulla eget, porttitor massa. Proin laoreet accumsan est, sed hendrerit tortor convallis at. Fusce eros metus, sagittis id metus euismod, ultrices tincidunt diam.\r\n\r\nNam tincidunt risus quis eros mollis feugiat. Quisque consequat magna purus, eu interdum libero tristique vel. Suspendisse in nulla a metus volutpat fringilla tincidunt vel lorem. Fusce tortor nisi, viverra nec placerat at, semper quis arcu. Cras semper ornare mauris in blandit. Donec at ipsum nec orci pellentesque tincidunt at vel lacus. In posuere, augue non tristique ultricies, est diam molestie turpis, vel scelerisque est lorem et massa. Ut quis sem et est ultrices semper sit amet sit amet neque. Phasellus volutpat imperdiet tellus. Aenean in malesuada massa. Quisque nec tempor ex, venenatis tincidunt purus. Donec justo dolor, fringilla sit amet eros ac, dignissim elementum ante. Pellentesque elementum volutpat lectus, luctus convallis urna rhoncus nec. Nunc sit amet nisl ornare, molestie sapien eu, hendrerit lectus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc ut erat sit amet dolor mollis mollis.\r\n\r\nCurabitur pellentesque semper ligula, et lacinia purus pellentesque a. Curabitur finibus, nunc pretium cursus pretium, sapien metus vestibulum metus, non scelerisque lectus quam commodo leo. Sed faucibus, libero sit amet porta convallis, sem lacus hendrerit dolor, vitae convallis odio nibh at arcu. Praesent iaculis hendrerit venenatis. Donec vitae ex ex. Maecenas in augue consequat, fringilla nisi a, cursus enim. Mauris ac pulvinar erat, pulvinar elementum libero. Praesent ut lobortis mauris. Sed ut pellentesque ex, malesuada auctor nibh. Nunc interdum lacus et elit molestie suscipit. Integer gravida arcu vel massa convallis, vestibulum accumsan felis ultricies. Maecenas ac placerat magna. Fusce quis tellus turpis.\r\n\r\nInterdum et malesuada fames ac ante ipsum primis in faucibus. Curabitur tortor lorem, varius sed tempor eu, hendrerit ac lorem. Quisque eget ante mi. Suspendisse potenti. Integer dictum convallis mi sed elementum. Nunc sodales libero at elementum scelerisque. Integer sit amet sollicitudin sapien, eleifend maximus odio. Aenean quis nisi at sapien molestie tempus. Aenean felis tellus, rhoncus sed massa vitae, vehicula ultrices enim. Aliquam erat volutpat. Donec quis felis ut orci lacinia commodo. Aliquam feugiat blandit libero, scelerisque lobortis sapien pretium tristique. Suspendisse magna orci, suscipit a interdum vitae, vehicula a nulla. Ut lobortis pulvinar ultrices. Pellentesque id diam sit amet nunc mollis aliquet malesuada ut justo. In hac habitasse platea dictumst.\r\n\r\nMauris et tortor ac nunc lobortis vehicula eu a neque. Vivamus pretium lorem ac quam tristique sollicitudin in egestas purus. Vivamus id dolor dolor. Integer ut fringilla sem. Etiam viverra augue sit amet lacinia eleifend. Aenean tellus mauris, dictum nec ante id, consequat dapibus tortor. In nec tortor sit amet neq War II and this effect to humanity development', 0, '2024-03-16 04:48:10'),
(3, 2, 'Motive', 'Live have to be motjkkived by yourself to raise sassathe future', 0, '2024-03-16 04:48:10'),
(5, 4, 'Hidup seperti Larryyyy', 'gfyhfjd', 1, '2023-12-09 06:38:18'),
(7, 4, 'Saya Anak dari Ibuku', 'Kasih Ibu Sepanjang Masa', 1, '2023-12-29 10:41:31'),
(8, 2, 'Selamat Datang Ke Real World', 'Saya ini Upin', 0, '2024-03-16 04:48:10'),
(10, 2, 'vggmvghgh', 'vyhyghvggyh', 0, '2024-03-16 04:48:10'),
(14, 4, 'aku anak sehat', 'aaaaaaaaaaaa', 1, '2024-03-15 19:02:46'),
(17, 4, 'aaaaaaaaaaaa', 'aaaaa111', 1, '2024-03-15 19:28:34');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `ID` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `noHp` varchar(20) NOT NULL,
  `current_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`ID`, `username`, `password`, `email`, `noHp`, `current_time`) VALUES
(19, 'rar1234', '$2y$10$xkyFFpmCWV/s3vFMxJt4vO/E66zbt8AI9PdxDTCQc9qZ/F9mDO.Q.', 'goo@gmail.com', '444454', '2024-03-15 17:23:52');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ID`);

--
-- Indeks untuk tabel `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_categorys` (`id_category`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `category`
--
ALTER TABLE `category`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `page`
--
ALTER TABLE `page`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `page`
--
ALTER TABLE `page`
  ADD CONSTRAINT `fk_categorys` FOREIGN KEY (`id_category`) REFERENCES `category` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
